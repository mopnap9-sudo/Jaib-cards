package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.local.entity.RechargeCard
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.formatTimestamp
import com.example.ui.localization.LocalAppStrings
import com.example.ui.viewmodel.JaibCardsUiState

@Composable
fun InventoryScreen(
    uiState: JaibCardsUiState,
    onAddCustomCategory: (Int) -> Unit,
    onImportCards: (categoryAmount: Int, rawText: String, skipDuplicates: Boolean, onDone: () -> Unit) -> Unit,
    onDeleteCard: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current
    val availableCategories = remember(uiState.categoryStocks) {
        val list = uiState.categoryStocks.map { it.categoryAmount }
        list.ifEmpty { listOf(500, 1000, 2000, 5000, 10000) }
    }

    var selectedCategory by remember(availableCategories) {
        mutableIntStateOf(availableCategories.first())
    }
    var bulkText by remember { mutableStateOf("") }
    var skipDuplicates by remember { mutableStateOf(true) }
    var searchQuery by remember { mutableStateOf("") }
    var showCustomCategoryDialog by remember { mutableStateOf(false) }
    var cardPendingDelete by remember { mutableStateOf<RechargeCard?>(null) }

    val parsedLinesCount = remember(bulkText) {
        bulkText.split("\n", "\r", ",", "،", ";")
            .map { it.trim() }
            .count { it.isNotEmpty() }
    }

    val filteredCards = remember(uiState.availableCards, searchQuery) {
        val query = searchQuery.trim()
        if (query.isEmpty()) {
            uiState.availableCards
        } else {
            uiState.availableCards.filter { card ->
                card.cardNumber.contains(query, ignoreCase = true) ||
                    card.categoryAmount.toString().contains(query)
            }
        }
    }

    if (showCustomCategoryDialog) {
        CustomCategoryDialog(
            onDismiss = { showCustomCategoryDialog = false },
            onConfirm = { amount ->
                onAddCustomCategory(amount)
                selectedCategory = amount
                showCustomCategoryDialog = false
            }
        )
    }

    cardPendingDelete?.let { pending ->
        AlertDialog(
            onDismissRequest = { cardPendingDelete = null },
            containerColor = MaterialTheme.colorScheme.surface,
            title = { Text(strings.deleteCardConfirmTitle) },
            text = {
                Text("${strings.deleteCardConfirmDesc}\n\n${pending.cardNumber}")
            },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteCard(pending.id)
                        cardPendingDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    )
                ) {
                    Text(strings.deleteBtn)
                }
            },
            dismissButton = {
                TextButton(onClick = { cardPendingDelete = null }) {
                    Text(strings.cancelBtn)
                }
            }
        )
    }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = strings.inventoryTitle,
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onBackground
            )
        }

        // اختيار الفئة
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = strings.selectCategoryLabel,
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(availableCategories) { category ->
                        val isSelected = selectedCategory == category
                        val stockCount = uiState.categoryStocks
                            .firstOrNull { it.categoryAmount == category }?.count ?: 0
                        FilterChip(
                            selected = isSelected,
                            onClick = { selectedCategory = category },
                            label = {
                                Text(
                                    text = "$category ${strings.currencyUnit} ($stockCount)",
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primary,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                            ),
                            modifier = Modifier.testTag("inventory_category_chip_$category")
                        )
                    }
                    item {
                        FilterChip(
                            selected = false,
                            onClick = { showCustomCategoryDialog = true },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Filled.Add,
                                    contentDescription = strings.customCategoryLabel,
                                    modifier = Modifier.size(16.dp)
                                )
                            },
                            label = { Text(strings.customCategoryLabel) },
                            modifier = Modifier.testTag("add_custom_category_chip")
                        )
                    }
                }
            }
        }

        // بطاقة الاستيراد الجماعي CSV / أسطر متعددة
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.UploadFile,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = strings.bulkImportTitle,
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.primaryContainer
                        ) {
                            Text(
                                text = strings.categoryFormat(selectedCategory),
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Text(
                        text = strings.bulkImportHint,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    OutlinedTextField(
                        value = bulkText,
                        onValueChange = { bulkText = it },
                        placeholder = { Text(strings.bulkImportPlaceholder) },
                        minLines = 5,
                        maxLines = 8,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("bulk_import_input")
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = strings.linesReadyCount(parsedLinesCount),
                            style = MaterialTheme.typography.labelMedium,
                            color = if (parsedLinesCount > 0) {
                                MaterialTheme.colorScheme.primary
                            } else {
                                MaterialTheme.colorScheme.onSurfaceVariant
                            }
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            TextButton(
                                onClick = {
                                    bulkText = "4410-8821-9034\n4410-8821-9035\n4410-8821-9036\n4410-8821-9037\n4410-8821-9038"
                                },
                                modifier = Modifier.testTag("bulk_sample_button")
                            ) {
                                Text(strings.pasteSampleBtn)
                            }
                            if (bulkText.isNotEmpty()) {
                                TextButton(
                                    onClick = { bulkText = "" },
                                    modifier = Modifier.testTag("bulk_clear_button")
                                ) {
                                    Text(strings.clearTextBtn)
                                }
                            }
                        }
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Checkbox(
                            checked = skipDuplicates,
                            onCheckedChange = { skipDuplicates = it },
                            colors = CheckboxDefaults.colors(
                                checkedColor = MaterialTheme.colorScheme.primary
                            ),
                            modifier = Modifier.testTag("skip_duplicates_checkbox")
                        )
                        Text(
                            text = strings.skipDuplicatesLabel,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Button(
                        onClick = {
                            onImportCards(selectedCategory, bulkText, skipDuplicates) {
                                bulkText = ""
                            }
                        },
                        enabled = parsedLinesCount > 0,
                        modifier = Modifier
                            .fillMaxWidth()
                            .minimumInteractiveComponentSize()
                            .testTag("import_cards_button"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = MaterialTheme.colorScheme.onPrimary
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Filled.UploadFile,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = strings.importCardsBtn,
                            style = MaterialTheme.typography.labelLarge
                        )
                    }
                }
            }
        }

        // قائمة الكروت المتوفرة
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "${strings.availableCardsListTitle} (${filteredCards.size})",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onBackground
                )
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text(strings.searchCardHint) },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Filled.Search,
                            contentDescription = null
                        )
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(
                                    imageVector = Icons.Filled.Clear,
                                    contentDescription = strings.clearTextBtn
                                )
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("inventory_search_input")
                )
            }
        }

        if (filteredCards.isEmpty()) {
            item {
                EmptyStateCard(
                    icon = Icons.Filled.Inventory2,
                    title = strings.emptyInventoryTitle,
                    description = strings.emptyInventoryDesc
                )
            }
        } else {
            items(
                items = filteredCards,
                key = { it.id }
            ) { card ->
                AvailableCardRow(
                    card = card,
                    onDeleteClick = { cardPendingDelete = card }
                )
            }
        }

        item { Spacer(modifier = Modifier.height(8.dp)) }
    }
}

@Composable
private fun AvailableCardRow(
    card: RechargeCard,
    onDeleteClick: () -> Unit
) {
    val strings = LocalAppStrings.current
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("available_card_item_${card.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.primaryContainer
                ) {
                    Text(
                        text = "${card.categoryAmount} ${strings.currencyUnit}",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }

                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(
                        text = card.cardNumber,
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = formatTimestamp(card.addedAt),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            IconButton(
                onClick = onDeleteClick,
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("delete_card_button_${card.id}")
            ) {
                Icon(
                    imageVector = Icons.Filled.DeleteOutline,
                    contentDescription = strings.deleteBtn,
                    tint = MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}

@Composable
private fun CustomCategoryDialog(
    onDismiss: () -> Unit,
    onConfirm: (Int) -> Unit
) {
    val strings = LocalAppStrings.current
    var amountInput by remember { mutableStateOf("") }
    val parsedAmount = amountInput.trim().toIntOrNull()

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        title = { Text(strings.customCategoryDialogTitle) },
        text = {
            OutlinedTextField(
                value = amountInput,
                onValueChange = { input ->
                    if (input.all { it.isDigit() }) amountInput = input
                },
                label = { Text(strings.customCategoryInputLabel) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("custom_category_input")
            )
        },
        confirmButton = {
            Button(
                onClick = { parsedAmount?.let { onConfirm(it) } },
                enabled = parsedAmount != null && parsedAmount > 0,
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                ),
                modifier = Modifier.testTag("confirm_custom_category_button")
            ) {
                Text(strings.addBtn)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(strings.cancelBtn)
            }
        }
    )
}
