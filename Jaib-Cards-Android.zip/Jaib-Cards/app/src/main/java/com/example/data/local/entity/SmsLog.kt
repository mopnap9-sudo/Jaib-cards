package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * حالات معالجة الرسائل القصيرة الواردة.
 */
enum class SmsStatus {
    DISPENSED,          // تم صرف الكرت وإرساله بنجاح
    OUT_OF_STOCK,       // الفئة مطابقة لكن المخزون نفد
    MISMATCH_AMOUNT,    // المبلغ لا يطابق أي فئة مدعومة
    DUPLICATE_IGNORED,  // رسالة مكررة خلال 60 ثانية تم تجاهلها
    SERVICE_INACTIVE,   // الخدمة متوقفة حالياً
    PARSE_FAILED,       // تعذر استخراج المبلغ أو رقم العميل
    FILTERED_OUT        // رسالة من المرسل لا تحتوي على الكلمة المفتاحية
}

/**
 * كيان سجل الرسائل القصيرة الواردة وحالة معالجتها والرد المرسل.
 */
@Entity(
    tableName = "sms_logs",
    indices = [
        Index(value = ["timestamp"]),
        Index(value = ["extractedPhone", "timestamp"])
    ]
)
data class SmsLog(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sender: String,
    val rawBody: String,
    val extractedAmount: Int? = null,
    val extractedPhone: String? = null,
    val status: SmsStatus,
    val replySent: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)
