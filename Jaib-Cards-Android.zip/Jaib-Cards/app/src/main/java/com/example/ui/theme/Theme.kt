package com.example.ui.theme

import android.app.Activity
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ProvideTextStyle
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.LayoutDirection
import androidx.core.view.WindowCompat
import com.example.ui.localization.ArabicStrings
import com.example.ui.localization.EnglishStrings
import com.example.ui.localization.LocalAppStrings

private val JaibDarkColorScheme = darkColorScheme(
    primary = CrimsonRed,
    onPrimary = PureWhite,
    primaryContainer = VelvetRedDark,
    onPrimaryContainer = SoftRedTint,
    secondary = PureWhite,
    onSecondary = ObsidianBlack,
    secondaryContainer = GraphiteHigh,
    onSecondaryContainer = PureWhite,
    tertiary = CrimsonRedSoft,
    onTertiary = PureWhite,
    background = ObsidianBlack,
    onBackground = PureWhite,
    surface = CharcoalSurface,
    onSurface = PureWhite,
    surfaceVariant = GraphiteElevated,
    onSurfaceVariant = DarkMutedText,
    surfaceContainerLowest = ObsidianBlack,
    surfaceContainerLow = CharcoalSurface,
    surfaceContainer = GraphiteElevated,
    surfaceContainerHigh = GraphiteHigh,
    surfaceContainerHighest = GraphiteHigh,
    outline = DarkOutline,
    outlineVariant = DarkOutline,
    error = CrimsonRedSoft,
    onError = PureWhite,
    errorContainer = VelvetRedDark,
    onErrorContainer = SoftRedTint
)

private val JaibLightColorScheme = lightColorScheme(
    primary = CrimsonRedDark,
    onPrimary = PureWhite,
    primaryContainer = VelvetRedLight,
    onPrimaryContainer = DeepRedText,
    secondary = InkBlack,
    onSecondary = PureWhite,
    secondaryContainer = PorcelainHigh,
    onSecondaryContainer = InkBlack,
    tertiary = CrimsonRed,
    onTertiary = PureWhite,
    background = AlabasterWhite,
    onBackground = InkBlack,
    surface = PureWhite,
    onSurface = InkBlack,
    surfaceVariant = PorcelainSurface,
    onSurfaceVariant = LightMutedText,
    surfaceContainerLowest = PureWhite,
    surfaceContainerLow = AlabasterWhite,
    surfaceContainer = PorcelainSurface,
    surfaceContainerHigh = PorcelainHigh,
    surfaceContainerHighest = PorcelainHigh,
    outline = LightOutline,
    outlineVariant = LightOutline,
    error = CrimsonRedDark,
    onError = PureWhite,
    errorContainer = VelvetRedLight,
    onErrorContainer = DeepRedText
)

@Composable
fun JaibCardsTheme(
    darkTheme: Boolean = true,
    languageCode: String = "ar",
    content: @Composable () -> Unit
) {
    val isArabic = languageCode.lowercase() == "ar"
    val colorScheme = if (darkTheme) JaibDarkColorScheme else JaibLightColorScheme
    val layoutDirection = if (isArabic) LayoutDirection.Rtl else LayoutDirection.Ltr
    val strings = if (isArabic) ArabicStrings else EnglishStrings

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val activity = view.context as? Activity
            activity?.window?.let { window ->
                val controller = WindowCompat.getInsetsController(window, view)
                controller.isAppearanceLightStatusBars = !darkTheme
                controller.isAppearanceLightNavigationBars = !darkTheme
            }
        }
    }

    CompositionLocalProvider(
        LocalLayoutDirection provides layoutDirection,
        LocalAppStrings provides strings
    ) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = JaibCardsTypography
        ) {
            ProvideTextStyle(
                value = LocalTextStyle.current.copy(fontFamily = IbmPlexSansArabicFamily),
                content = content
            )
        }
    }
}
