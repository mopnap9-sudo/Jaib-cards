package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.local.entity.SoldCard
import kotlinx.coroutines.flow.Flow

data class TodaySalesSummary(
    val count: Int = 0,
    val totalAmount: Long = 0L
)

@Dao
interface SoldCardDao {
    @Query("SELECT * FROM sold_cards ORDER BY soldAt DESC, id DESC")
    fun observeAllSoldCards(): Flow<List<SoldCard>>

    @Query(
        "SELECT COUNT(*) AS count, COALESCE(SUM(categoryAmount), 0) AS totalAmount " +
            "FROM sold_cards WHERE soldAt >= :startOfDayMillis"
    )
    fun observeTodaySalesSummary(startOfDayMillis: Long): Flow<TodaySalesSummary>

    @Query("SELECT DISTINCT categoryAmount FROM sold_cards")
    suspend fun getDistinctCategories(): List<Int>

    @Query("SELECT EXISTS(SELECT 1 FROM sold_cards WHERE cardNumber = :cardNumber)")
    suspend fun existsByCardNumber(cardNumber: String): Boolean

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(soldCard: SoldCard): Long

    @Query("DELETE FROM sold_cards")
    suspend fun clearAll()
}
