package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * كيان يمثل كرت شحن متاح للبيع في قاعدة البيانات المحلية.
 */
@Entity(
    tableName = "recharge_cards",
    indices = [
        Index(value = ["categoryAmount"]),
        Index(value = ["cardNumber"], unique = true)
    ]
)
data class RechargeCard(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val categoryAmount: Int,
    val cardNumber: String,
    val addedAt: Long = System.currentTimeMillis()
)
