package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.local.entity.RechargeCard
import kotlinx.coroutines.flow.Flow

data class CategoryStockCount(
    val categoryAmount: Int,
    val count: Int
)

@Dao
interface RechargeCardDao {
    @Query("SELECT * FROM recharge_cards ORDER BY categoryAmount ASC, addedAt ASC")
    fun observeAllCards(): Flow<List<RechargeCard>>

    @Query(
        "SELECT categoryAmount, COUNT(*) AS count FROM recharge_cards " +
            "GROUP BY categoryAmount ORDER BY categoryAmount ASC"
    )
    fun observeCategoryStockCounts(): Flow<List<CategoryStockCount>>

    @Query("SELECT DISTINCT categoryAmount FROM recharge_cards")
    suspend fun getDistinctCategories(): List<Int>

    @Query(
        "SELECT * FROM recharge_cards WHERE categoryAmount = :categoryAmount " +
            "ORDER BY addedAt ASC, id ASC LIMIT 1"
    )
    suspend fun getFirstAvailableByCategory(categoryAmount: Int): RechargeCard?

    @Query("SELECT EXISTS(SELECT 1 FROM recharge_cards WHERE cardNumber = :cardNumber)")
    suspend fun existsByCardNumber(cardNumber: String): Boolean

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(cards: List<RechargeCard>): List<Long>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(card: RechargeCard): Long

    @Query("DELETE FROM recharge_cards WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM recharge_cards WHERE categoryAmount = :categoryAmount")
    suspend fun deleteByCategory(categoryAmount: Int)
}
