package com.example

import android.app.Application
import com.example.data.local.AppDatabase
import com.example.data.repository.CardRepository
import com.example.data.sms.AndroidSmsDispatcher
import com.example.data.sms.SmsDispatcher

/**
 * كلاس التطبيق الرئيسي الذي يوفر نسخة واحدة مشتركة من قاعدة البيانات والمستودع
 * لضمان عمل قفل التزامن (Mutex) بين مستقبل الرسائل وواجهة المستخدم.
 */
class JaibCardsApplication : Application() {
    val database: AppDatabase by lazy { AppDatabase.getInstance(this) }
    val smsDispatcher: SmsDispatcher by lazy { AndroidSmsDispatcher(this) }
    val repository: CardRepository by lazy { CardRepository(database, smsDispatcher) }
}
