package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Inventory2
import androidx.compose.material.icons.outlined.ReceiptLong
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.data.local.dao.TodaySalesSummary
import com.example.data.local.entity.AppSettings
import com.example.ui.localization.LocalAppStrings
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.InventoryScreen
import com.example.ui.screens.LogsScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.JaibCardsTheme
import com.example.ui.viewmodel.CategoryStockUiItem
import com.example.ui.viewmodel.JaibCardsUiState
import com.example.ui.viewmodel.JaibCardsViewModel
import kotlinx.coroutines.launch

const val ROUTE_HOME = "home"
const val ROUTE_INVENTORY = "inventory"
const val ROUTE_LOGS = "logs"
const val ROUTE_SETTINGS = "settings"

private data class NavTabItem(
    val route: String,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val app = application as JaibCardsApplication

        setContent {
            val viewModel: JaibCardsViewModel = viewModel(
                factory = JaibCardsViewModel.provideFactory(app.repository)
            )
            val uiState by viewModel.uiState.collectAsStateWithLifecycle()

            JaibCardsTheme(
                darkTheme = uiState.settings.isDarkMode,
                languageCode = uiState.settings.languageCode
            ) {
                JaibCardsAppShell(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun JaibCardsAppShell(viewModel: JaibCardsViewModel) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val strings = LocalAppStrings.current
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val snackbarHostState = remember { SnackbarHostState() }
    val coroutineScope = rememberCoroutineScope()

    val requiredPermissions = remember {
        arrayOf(
            Manifest.permission.RECEIVE_SMS,
            Manifest.permission.READ_SMS,
            Manifest.permission.SEND_SMS
        )
    }

    fun checkPermissionsGranted(): Boolean {
        return requiredPermissions.all { permission ->
            ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
        }
    }

    var hasSmsPermissions by remember { mutableStateOf(checkPermissionsGranted()) }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) {
        hasSmsPermissions = checkPermissionsGranted()
    }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                hasSmsPermissions = checkPermissionsGranted()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    LaunchedEffect(viewModel) {
        viewModel.uiMessages.collect { message ->
            snackbarHostState.showSnackbar(message)
        }
    }

    JaibCardsMainContent(
        uiState = uiState,
        hasSmsPermissions = hasSmsPermissions,
        snackbarHostState = snackbarHostState,
        onRequestPermissions = { permissionLauncher.launch(requiredPermissions) },
        onToggleService = { viewModel.toggleServiceActive(it) },
        onSimulateSms = { sender, body -> viewModel.simulateIncomingSms(sender, body, strings) },
        onAddCustomCategory = { viewModel.addCustomCategory(it) },
        onImportCards = { category, rawText, skipDuplicates, onDone ->
            viewModel.importCardsBulk(
                categoryAmount = category,
                rawText = rawText,
                skipDuplicates = skipDuplicates,
                strings = strings,
                onComplete = { onDone() }
            )
        },
        onDeleteCard = { viewModel.deleteAvailableCard(it) },
        onClearSmsLogs = { viewModel.clearSmsLogs() },
        onClearSoldCards = { viewModel.clearSoldCards() },
        onLanguageChange = { viewModel.setLanguageCode(it) },
        onDarkModeChange = { viewModel.setDarkMode(it) },
        onSaveSettings = { viewModel.saveSettings(it, strings) },
        onResetDefaults = { viewModel.resetSettingsToDefaults(strings) },
        onShowMessage = { msg ->
            coroutineScope.launch {
                snackbarHostState.showSnackbar(msg)
            }
        }
    )
}

@Composable
fun JaibCardsMainContent(
    uiState: JaibCardsUiState,
    hasSmsPermissions: Boolean,
    snackbarHostState: SnackbarHostState,
    onRequestPermissions: () -> Unit,
    onToggleService: (Boolean) -> Unit,
    onSimulateSms: (sender: String, body: String) -> Unit,
    onAddCustomCategory: (Int) -> Unit,
    onImportCards: (categoryAmount: Int, rawText: String, skipDuplicates: Boolean, onDone: () -> Unit) -> Unit,
    onDeleteCard: (Long) -> Unit,
    onClearSmsLogs: () -> Unit,
    onClearSoldCards: () -> Unit,
    onLanguageChange: (String) -> Unit,
    onDarkModeChange: (Boolean) -> Unit,
    onSaveSettings: (AppSettings) -> Unit,
    onResetDefaults: () -> Unit,
    onShowMessage: (String) -> Unit
) {
    val strings = LocalAppStrings.current
    val navController = rememberNavController()

    val navItems = remember(strings) {
        listOf(
            NavTabItem(
                route = ROUTE_HOME,
                label = strings.navHome,
                selectedIcon = Icons.Filled.Home,
                unselectedIcon = Icons.Outlined.Home,
                testTag = "nav_tab_home"
            ),
            NavTabItem(
                route = ROUTE_INVENTORY,
                label = strings.navInventory,
                selectedIcon = Icons.Filled.Inventory2,
                unselectedIcon = Icons.Outlined.Inventory2,
                testTag = "nav_tab_inventory"
            ),
            NavTabItem(
                route = ROUTE_LOGS,
                label = strings.navLogs,
                selectedIcon = Icons.Filled.ReceiptLong,
                unselectedIcon = Icons.Outlined.ReceiptLong,
                testTag = "nav_tab_logs"
            ),
            NavTabItem(
                route = ROUTE_SETTINGS,
                label = strings.navSettings,
                selectedIcon = Icons.Filled.Settings,
                unselectedIcon = Icons.Outlined.Settings,
                testTag = "nav_tab_settings"
            )
        )
    }

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route ?: ROUTE_HOME

    fun navigateToTab(route: String) {
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useNavigationRail = maxWidth >= 600.dp

        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = MaterialTheme.colorScheme.background,
            contentWindowInsets = WindowInsets.safeDrawing,
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
            bottomBar = {
                if (!useNavigationRail) {
                    NavigationBar(
                        containerColor = MaterialTheme.colorScheme.surface,
                        contentColor = MaterialTheme.colorScheme.onSurface
                    ) {
                        navItems.forEach { item ->
                            val selected = currentRoute == item.route
                            NavigationBarItem(
                                selected = selected,
                                onClick = { navigateToTab(item.route) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                                        contentDescription = item.label
                                    )
                                },
                                label = { Text(item.label, maxLines = 1) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = MaterialTheme.colorScheme.primary,
                                    selectedTextColor = MaterialTheme.colorScheme.primary,
                                    indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                                ),
                                modifier = Modifier.testTag(item.testTag)
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useNavigationRail) {
                    NavigationRail(
                        containerColor = MaterialTheme.colorScheme.surface,
                        contentColor = MaterialTheme.colorScheme.onSurface
                    ) {
                        navItems.forEach { item ->
                            val selected = currentRoute == item.route
                            NavigationRailItem(
                                selected = selected,
                                onClick = { navigateToTab(item.route) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                                        contentDescription = item.label
                                    )
                                },
                                label = { Text(item.label) },
                                colors = NavigationRailItemDefaults.colors(
                                    selectedIconColor = MaterialTheme.colorScheme.primary,
                                    selectedTextColor = MaterialTheme.colorScheme.primary,
                                    indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                                ),
                                modifier = Modifier.testTag(item.testTag)
                            )
                        }
                    }
                }

                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.TopCenter
                ) {
                    NavHost(
                        navController = navController,
                        startDestination = ROUTE_HOME,
                        modifier = Modifier
                            .widthIn(max = 760.dp)
                            .fillMaxSize()
                    ) {
                        composable(ROUTE_HOME) {
                            HomeScreen(
                                uiState = uiState,
                                hasSmsPermissions = hasSmsPermissions,
                                onRequestPermissions = onRequestPermissions,
                                onToggleService = onToggleService,
                                onNavigateToInventory = { navigateToTab(ROUTE_INVENTORY) },
                                onSimulateSms = onSimulateSms
                            )
                        }

                        composable(ROUTE_INVENTORY) {
                            InventoryScreen(
                                uiState = uiState,
                                onAddCustomCategory = onAddCustomCategory,
                                onImportCards = onImportCards,
                                onDeleteCard = onDeleteCard
                            )
                        }

                        composable(ROUTE_LOGS) {
                            LogsScreen(
                                uiState = uiState,
                                onClearSmsLogs = onClearSmsLogs,
                                onClearSoldCards = onClearSoldCards,
                                onShowMessage = onShowMessage
                            )
                        }

                        composable(ROUTE_SETTINGS) {
                            SettingsScreen(
                                settings = uiState.settings,
                                onLanguageChange = onLanguageChange,
                                onDarkModeChange = onDarkModeChange,
                                onSaveSettings = onSaveSettings,
                                onResetDefaults = onResetDefaults,
                                onShowMessage = onShowMessage
                            )
                        }
                    }
                }
            }
        }
    }
}

@Preview(showBackground = true, name = "Jaib-Cards Home Dark Arabic")
@Composable
fun JaibCardsDarkArabicPreview() {
    val sampleState = JaibCardsUiState(
        settings = AppSettings(isDarkMode = true, languageCode = "ar"),
        todaySales = TodaySalesSummary(count = 14, totalAmount = 18500),
        categoryStocks = listOf(
            CategoryStockUiItem(500, 12, isLowStock = false),
            CategoryStockUiItem(1000, 3, isLowStock = true),
            CategoryStockUiItem(2000, 0, isLowStock = true),
            CategoryStockUiItem(5000, 8, isLowStock = false)
        ),
        totalAvailableStock = 23
    )
    JaibCardsTheme(darkTheme = true, languageCode = "ar") {
        JaibCardsMainContent(
            uiState = sampleState,
            hasSmsPermissions = false,
            snackbarHostState = remember { SnackbarHostState() },
            onRequestPermissions = {},
            onToggleService = {},
            onSimulateSms = { _, _ -> },
            onAddCustomCategory = {},
            onImportCards = { _, _, _, _ -> },
            onDeleteCard = {},
            onClearSmsLogs = {},
            onClearSoldCards = {},
            onLanguageChange = {},
            onDarkModeChange = {},
            onSaveSettings = {},
            onResetDefaults = {},
            onShowMessage = {}
        )
    }
}

@Preview(showBackground = true, name = "Jaib-Cards Home Light English")
@Composable
fun JaibCardsLightEnglishPreview() {
    val sampleState = JaibCardsUiState(
        settings = AppSettings(isDarkMode = false, languageCode = "en"),
        todaySales = TodaySalesSummary(count = 9, totalAmount = 12000),
        categoryStocks = listOf(
            CategoryStockUiItem(500, 10, isLowStock = false),
            CategoryStockUiItem(1000, 2, isLowStock = true)
        ),
        totalAvailableStock = 12
    )
    JaibCardsTheme(darkTheme = false, languageCode = "en") {
        JaibCardsMainContent(
            uiState = sampleState,
            hasSmsPermissions = true,
            snackbarHostState = remember { SnackbarHostState() },
            onRequestPermissions = {},
            onToggleService = {},
            onSimulateSms = { _, _ -> },
            onAddCustomCategory = {},
            onImportCards = { _, _, _, _ -> },
            onDeleteCard = {},
            onClearSmsLogs = {},
            onClearSoldCards = {},
            onLanguageChange = {},
            onDarkModeChange = {},
            onSaveSettings = {},
            onResetDefaults = {},
            onShowMessage = {}
        )
    }
}
