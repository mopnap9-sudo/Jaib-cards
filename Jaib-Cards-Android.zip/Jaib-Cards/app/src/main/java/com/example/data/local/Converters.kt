package com.example.data.local

import androidx.room.TypeConverter
import com.example.data.local.entity.SmsStatus

class Converters {
    @TypeConverter
    fun fromSmsStatus(status: SmsStatus): String = status.name

    @TypeConverter
    fun toSmsStatus(value: String): SmsStatus {
        return runCatching { SmsStatus.valueOf(value) }.getOrDefault(SmsStatus.PARSE_FAILED)
    }
}
