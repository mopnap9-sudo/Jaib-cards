package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.local.dao.AppSettingsDao
import com.example.data.local.dao.RechargeCardDao
import com.example.data.local.dao.SmsLogDao
import com.example.data.local.dao.SoldCardDao
import com.example.data.local.entity.AppSettings
import com.example.data.local.entity.RechargeCard
import com.example.data.local.entity.SmsLog
import com.example.data.local.entity.SoldCard
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        RechargeCard::class,
        SoldCard::class,
        SmsLog::class,
        AppSettings::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun rechargeCardDao(): RechargeCardDao
    abstract fun soldCardDao(): SoldCardDao
    abstract fun smsLogDao(): SmsLogDao
    abstract fun appSettingsDao(): AppSettingsDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: buildDatabase(context.applicationContext).also { INSTANCE = it }
            }
        }

        private fun buildDatabase(appContext: Context): AppDatabase {
            return Room.databaseBuilder(
                appContext,
                AppDatabase::class.java,
                "jaib_cards_db"
            )
                .addCallback(object : Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        CoroutineScope(Dispatchers.IO).launch {
                            getInstance(appContext).appSettingsDao().upsert(AppSettings())
                        }
                    }
                })
                .build()
        }
    }
}
