package com.example.data.repository

import androidx.room.withTransaction
import com.example.data.local.AppDatabase
import com.example.data.local.dao.CategoryStockCount
import com.example.data.local.dao.TodaySalesSummary
import com.example.data.local.entity.AppSettings
import com.example.data.local.entity.RechargeCard
import com.example.data.local.entity.SmsLog
import com.example.data.local.entity.SmsStatus
import com.example.data.local.entity.SoldCard
import com.example.data.sms.SmsDispatcher
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.Calendar

/**
 * نتيجة تحليل نص الرسالة القصيرة الواردة.
 */
data class ParsedSmsData(
    val amount: Int?,
    val phoneNumber: String?
)

/**
 * نتيجة معالجة الرسالة الواردة لعرضها أو تتبعها.
 */
sealed class SmsProcessingResult {
    data class Dispensed(
        val amount: Int,
        val cardNumber: String,
        val customerPhone: String,
        val smsSent: Boolean
    ) : SmsProcessingResult()

    data class OutOfStock(
        val amount: Int,
        val customerPhone: String,
        val ownerAlerted: Boolean
    ) : SmsProcessingResult()

    data class MismatchAmount(
        val amount: Int,
        val customerPhone: String
    ) : SmsProcessingResult()

    data object DuplicateIgnored : SmsProcessingResult()
    data object ServiceInactive : SmsProcessingResult()
    data object ParseFailed : SmsProcessingResult()
    data object FilteredOut : SmsProcessingResult()
}

/**
 * نتيجة استيراد الكروت الجماعي من نص CSV أو أسطر متعددة.
 */
data class BulkImportResult(
    val addedCount: Int,
    val duplicateOrEmptyCount: Int
)

/**
 * المستودع الرئيسي لإدارة المخزون ومعالجة رسائل الدفع الآلي باستخدام Mutex لمنع تداخل العمليات.
 */
class CardRepository(
    private val database: AppDatabase,
    private val smsDispatcher: SmsDispatcher
) {
    private val rechargeCardDao = database.rechargeCardDao()
    private val soldCardDao = database.soldCardDao()
    private val smsLogDao = database.smsLogDao()
    private val appSettingsDao = database.appSettingsDao()

    // قفل تزامن (Mutex) لمنع حدوث سباق البيانات (Race Condition) أو صرف نفس الكرت مرتين عند تزامن الرسائل
    private val processingMutex = Mutex()

    val settingsFlow: Flow<AppSettings> = appSettingsDao.observeSettings().map { it ?: AppSettings() }
    val allAvailableCardsFlow: Flow<List<RechargeCard>> = rechargeCardDao.observeAllCards()
    val categoryStockCountsFlow: Flow<List<CategoryStockCount>> =
        rechargeCardDao.observeCategoryStockCounts()
    val allSoldCardsFlow: Flow<List<SoldCard>> = soldCardDao.observeAllSoldCards()
    val allSmsLogsFlow: Flow<List<SmsLog>> = smsLogDao.observeAllLogs()

    fun observeTodaySalesSummary(): Flow<TodaySalesSummary> {
        return soldCardDao.observeTodaySalesSummary(startOfTodayMillis())
    }

    suspend fun getSettingsOnce(): AppSettings {
        val existing = appSettingsDao.getSettingsOnce()
        if (existing != null) return existing
        val defaults = AppSettings()
        appSettingsDao.upsert(defaults)
        return defaults
    }

    suspend fun updateSettings(settings: AppSettings) {
        appSettingsDao.upsert(settings.copy(id = 1))
    }

    suspend fun setServiceActive(active: Boolean) {
        val current = getSettingsOnce()
        appSettingsDao.upsert(current.copy(isServiceActive = active))
    }

    suspend fun setLanguageCode(languageCode: String) {
        val current = getSettingsOnce()
        appSettingsDao.upsert(current.copy(languageCode = languageCode))
    }

    suspend fun setDarkMode(isDarkMode: Boolean) {
        val current = getSettingsOnce()
        appSettingsDao.upsert(current.copy(isDarkMode = isDarkMode))
    }

    /**
     * استيراد قائمة كروت شحن بالجملة (كرت في كل سطر أو مفصولة بفواصل CSV) لفئة محددة.
     */
    suspend fun importCardsBulk(
        categoryAmount: Int,
        rawInput: String,
        skipDuplicates: Boolean = true
    ): BulkImportResult {
        if (categoryAmount <= 0) return BulkImportResult(0, 0)

        val tokens = rawInput
            .split("\n", "\r", ",", "،", ";")
            .map { it.trim() }
            .filter { it.isNotEmpty() }

        if (tokens.isEmpty()) return BulkImportResult(0, 0)

        var added = 0
        var skipped = 0
        val now = System.currentTimeMillis()
        val seenInBatch = HashSet<String>()

        val cardsToInsert = mutableListOf<RechargeCard>()
        for (token in tokens) {
            if (!seenInBatch.add(token)) {
                skipped++
                continue
            }
            if (skipDuplicates &&
                (rechargeCardDao.existsByCardNumber(token) || soldCardDao.existsByCardNumber(token))
            ) {
                skipped++
                continue
            }
            cardsToInsert.add(
                RechargeCard(
                    categoryAmount = categoryAmount,
                    cardNumber = token,
                    addedAt = now
                )
            )
        }

        if (cardsToInsert.isNotEmpty()) {
            val insertResults = rechargeCardDao.insertAll(cardsToInsert)
            insertResults.forEach { rowId ->
                if (rowId != -1L) added++ else skipped++
            }
        }

        // تحديث الفئات المدعومة تلقائياً إذا تمت إضافة فئة جديدة
        val currentSettings = getSettingsOnce()
        val categories = currentSettings.parsedSupportedCategories().toMutableSet()
        if (categories.add(categoryAmount)) {
            val sortedStr = categories.sorted().joinToString(",")
            appSettingsDao.upsert(currentSettings.copy(supportedCategories = sortedStr))
        }

        return BulkImportResult(addedCount = added, duplicateOrEmptyCount = skipped)
    }

    suspend fun deleteAvailableCard(cardId: Long) {
        rechargeCardDao.deleteById(cardId)
    }

    suspend fun clearSmsLogs() {
        smsLogDao.clearAll()
    }

    suspend fun clearSoldCards() {
        soldCardDao.clearAll()
    }

    /**
     * دالة تحليل نص الرسالة القصيرة لاستخراج مبلغ التحويل ورقم هاتف العميل.
     *
     * خطوات العمل:
     * 1. تحويل الأرقام العربية الهندية (٠-٩) والفارسية (۰-۹) إلى أرقام إنجليزية قياسية (0-9).
     * 2. استخراج أول رقم يسبق عبارة "ر.ي" أو "ريال" ليمثل مبلغ التحويل.
     * 3. استخراج آخر رقم هاتف في النص (مثل الأرقام اليمنية التي تبدأ بـ 7 مع دعم رمز الدولة الاختياري).
     */
    fun parseMessage(body: String): ParsedSmsData {
        val normalized = normalizeArabicDigits(body)
            .replace("٬", ",")
            .replace("٫", ".")

        // البحث عن أول قيمة عددية تسبق العملة (ر.ي أو ريال)
        val amountRegex = Regex("""(\d+(?:,\d{3})*(?:\.\d+)?)\s*(?:ر\.ي|ريال)""")
        val amountMatch = amountRegex.find(normalized)
        val parsedAmount = amountMatch
            ?.groupValues
            ?.getOrNull(1)
            ?.replace(",", "")
            ?.toDoubleOrNull()
            ?.toInt()

        // البحث عن آخر رقم هاتف في الرسالة (يبدأ بالرقم 7 بعد إزالة بادئة الدولة +967 أو 00967 إن وجدت)
        val phoneRegex = Regex("""(?<!\d)(?:\+?967|00967)?(7\d{7,9})(?!\d)""")
        val lastPhoneMatch = phoneRegex.findAll(normalized).lastOrNull()
        val parsedPhone = lastPhoneMatch?.groupValues?.getOrNull(1)

        return ParsedSmsData(
            amount = parsedAmount,
            phoneNumber = parsedPhone
        )
    }

    /**
     * دالة المعالجة الرئيسية للرسالة الواردة والمحمية بقفل Mutex لمنع تداخل الطلبات المتزامنة.
     *
     * خطوات العمل:
     * 1. التحقق من المرسل المسموح به (مثل Jaib) والكلمة المفتاحية (مثل اضيف) مع تجاهل حالة الأحرف.
     * 2. التحقق من أن خدمة البيع الآلي مفعّلة في الإعدادات.
     * 3. تحليل الرسالة عبر parseMessage لاستخراج المبلغ ورقم العميل.
     * 4. فحص التكرار: تجاهل أي رسالة مطابقة من نفس الرقم خلال آخر 60 ثانية.
     * 5. التعامل مع السيناريوهات الثلاثة:
     *    أ) توفر الكرت: نقل الكرت أولاً إلى جدول الكروت المباعة (sold_cards) ثم حذفه من المخزون وإرسال الرسالة للعميل.
     *    ب) نفاد المخزون: إذا كانت الفئة معروفة ولكن الرصيد 0، يتم إشعار العميل وتنبيه المالك عبر SMS.
     *    ج) عدم تطابق المبلغ: تسجيل العملية وإرسال قالب الرد الخاص بالمبالغ غير المطابقة للعميل.
     */
    suspend fun processMessage(
        sender: String,
        body: String,
        nowMillis: Long = System.currentTimeMillis()
    ): SmsProcessingResult = processingMutex.withLock {
        val settings = getSettingsOnce()
        val trimmedSender = sender.trim()
        val trimmedBody = body.trim()

        val allowedSender = settings.allowedSender.trim()
        val requiredKeyword = settings.requiredKeyword.trim()

        // 1. تصفية المرسل: يجب أن يطابق أو يحتوي على اسم المرسل المسموح به (مثلاً Jaib)
        val senderMatches = allowedSender.isEmpty() ||
            trimmedSender.equals(allowedSender, ignoreCase = true) ||
            trimmedSender.contains(allowedSender, ignoreCase = true)

        if (!senderMatches) {
            return@withLock SmsProcessingResult.FilteredOut
        }

        // التحقق من وجود الكلمة المفتاحية (مثلاً "اضيف") بدون حساسية لحالة الأحرف
        val keywordMatches = requiredKeyword.isEmpty() ||
            trimmedBody.contains(requiredKeyword, ignoreCase = true)

        if (!keywordMatches) {
            smsLogDao.insert(
                SmsLog(
                    sender = trimmedSender,
                    rawBody = trimmedBody,
                    status = SmsStatus.FILTERED_OUT,
                    timestamp = nowMillis
                )
            )
            return@withLock SmsProcessingResult.FilteredOut
        }

        // 2. التحقق من تفعيل الخدمة
        if (!settings.isServiceActive) {
            val parsed = parseMessage(trimmedBody)
            smsLogDao.insert(
                SmsLog(
                    sender = trimmedSender,
                    rawBody = trimmedBody,
                    extractedAmount = parsed.amount,
                    extractedPhone = parsed.phoneNumber,
                    status = SmsStatus.SERVICE_INACTIVE,
                    timestamp = nowMillis
                )
            )
            return@withLock SmsProcessingResult.ServiceInactive
        }

        // 3. تحليل النص لاستخراج المبلغ ورقم العميل
        val parsed = parseMessage(trimmedBody)
        val amount = parsed.amount
        val customerPhone = parsed.phoneNumber

        if (amount == null || amount <= 0 || customerPhone.isNullOrBlank()) {
            smsLogDao.insert(
                SmsLog(
                    sender = trimmedSender,
                    rawBody = trimmedBody,
                    extractedAmount = amount,
                    extractedPhone = customerPhone,
                    status = SmsStatus.PARSE_FAILED,
                    timestamp = nowMillis
                )
            )
            return@withLock SmsProcessingResult.ParseFailed
        }

        // 4. فحص منع التكرار: تجاهل الرسائل المطابقة تماماً من نفس رقم العميل خلال آخر 60 ثانية
        val duplicateCutoff = nowMillis - DUPLICATE_WINDOW_MS
        val duplicateCount = smsLogDao.countRecentMatchingMessages(
            phone = customerPhone,
            rawBody = trimmedBody,
            cutoffTimestamp = duplicateCutoff
        )
        if (duplicateCount > 0) {
            smsLogDao.insert(
                SmsLog(
                    sender = trimmedSender,
                    rawBody = trimmedBody,
                    extractedAmount = amount,
                    extractedPhone = customerPhone,
                    status = SmsStatus.DUPLICATE_IGNORED,
                    timestamp = nowMillis
                )
            )
            return@withLock SmsProcessingResult.DuplicateIgnored
        }

        // 5. تنفيذ السيناريو المناسب داخل معاملة قاعدة بيانات آمنة
        val availableCard = rechargeCardDao.getFirstAvailableByCategory(amount)

        if (availableCard != null) {
            // السيناريو (أ): الكرت متوفر — نُعِد نص الرد ثم ننقل الكرت لجدول المباع أولاً ثم نحذفه من المخزون
            val replyText = formatTemplate(
                template = settings.successTemplate,
                amount = amount,
                cardNumber = availableCard.cardNumber,
                customerPhone = customerPhone
            )

            database.withTransaction {
                val logId = smsLogDao.insert(
                    SmsLog(
                        sender = trimmedSender,
                        rawBody = trimmedBody,
                        extractedAmount = amount,
                        extractedPhone = customerPhone,
                        status = SmsStatus.DISPENSED,
                        replySent = replyText,
                        timestamp = nowMillis
                    )
                )
                // نقل الكرت إلى جدول الكروت المباعة أولاً
                soldCardDao.insert(
                    SoldCard(
                        categoryAmount = availableCard.categoryAmount,
                        cardNumber = availableCard.cardNumber,
                        customerPhone = customerPhone,
                        soldAt = nowMillis,
                        rawMessageId = logId
                    )
                )
                // ثم حذفه من جدول الكروت المتاحة
                rechargeCardDao.deleteById(availableCard.id)
            }

            val sent = smsDispatcher.sendSms(customerPhone, replyText)
            return@withLock SmsProcessingResult.Dispensed(
                amount = amount,
                cardNumber = availableCard.cardNumber,
                customerPhone = customerPhone,
                smsSent = sent
            )
        }

        // تحديد ما إذا كان المبلغ فئة معروفة نفد مخزونها أم مبلغ غير مطابق
        val knownCategories = buildSet {
            addAll(settings.parsedSupportedCategories())
            addAll(rechargeCardDao.getDistinctCategories())
            addAll(soldCardDao.getDistinctCategories())
        }

        if (amount in knownCategories) {
            // السيناريو (ب): نفاد المخزون — إرسال رسالة اعتذار للعميل وتنبيه المالك
            val replyText = formatTemplate(
                template = settings.outOfStockTemplate,
                amount = amount,
                cardNumber = "",
                customerPhone = customerPhone
            )
            smsLogDao.insert(
                SmsLog(
                    sender = trimmedSender,
                    rawBody = trimmedBody,
                    extractedAmount = amount,
                    extractedPhone = customerPhone,
                    status = SmsStatus.OUT_OF_STOCK,
                    replySent = replyText,
                    timestamp = nowMillis
                )
            )
            smsDispatcher.sendSms(customerPhone, replyText)

            val ownerPhone = settings.ownerPhone.trim()
            val ownerAlerted = if (ownerPhone.isNotEmpty()) {
                val alertMessage =
                    "تنبيه Jaib-Cards: نفاد مخزون كروت فئة $amount ر.ي! العميل $customerPhone بانتظار الكرت."
                smsDispatcher.sendSms(ownerPhone, alertMessage)
            } else {
                false
            }

            return@withLock SmsProcessingResult.OutOfStock(
                amount = amount,
                customerPhone = customerPhone,
                ownerAlerted = ownerAlerted
            )
        } else {
            // السيناريو (ج): المبلغ لا يطابق أي فئة كروت متوفرة
            val replyText = formatTemplate(
                template = settings.mismatchTemplate,
                amount = amount,
                cardNumber = "",
                customerPhone = customerPhone
            )
            smsLogDao.insert(
                SmsLog(
                    sender = trimmedSender,
                    rawBody = trimmedBody,
                    extractedAmount = amount,
                    extractedPhone = customerPhone,
                    status = SmsStatus.MISMATCH_AMOUNT,
                    replySent = replyText,
                    timestamp = nowMillis
                )
            )
            smsDispatcher.sendSms(customerPhone, replyText)

            return@withLock SmsProcessingResult.MismatchAmount(
                amount = amount,
                customerPhone = customerPhone
            )
        }
    }

    private fun formatTemplate(
        template: String,
        amount: Int,
        cardNumber: String,
        customerPhone: String
    ): String {
        return template
            .replace("{رقم_الكرت}", cardNumber)
            .replace("{الفئة}", amount.toString())
            .replace("{المبلغ}", amount.toString())
            .replace("{رقم_العميل}", customerPhone)
    }

    private fun normalizeArabicDigits(input: String): String {
        val builder = StringBuilder(input.length)
        for (ch in input) {
            when (ch) {
                in '٠'..'٩' -> builder.append(('0'.code + (ch.code - '٠'.code)).toChar())
                in '۰'..'۹' -> builder.append(('0'.code + (ch.code - '۰'.code)).toChar())
                else -> builder.append(ch)
            }
        }
        return builder.toString()
    }

    private fun startOfTodayMillis(): Long {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        return cal.timeInMillis
    }

    companion object {
        private const val DUPLICATE_WINDOW_MS = 60_000L
    }
}
