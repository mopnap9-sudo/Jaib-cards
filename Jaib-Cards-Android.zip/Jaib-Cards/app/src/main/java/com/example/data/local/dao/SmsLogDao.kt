package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.local.entity.SmsLog
import kotlinx.coroutines.flow.Flow

@Dao
interface SmsLogDao {
    @Query("SELECT * FROM sms_logs ORDER BY timestamp DESC, id DESC")
    fun observeAllLogs(): Flow<List<SmsLog>>

    @Query(
        "SELECT COUNT(*) FROM sms_logs " +
            "WHERE extractedPhone = :phone " +
            "AND rawBody = :rawBody " +
            "AND timestamp >= :cutoffTimestamp " +
            "AND status != 'DUPLICATE_IGNORED'"
    )
    suspend fun countRecentMatchingMessages(
        phone: String,
        rawBody: String,
        cutoffTimestamp: Long
    ): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(log: SmsLog): Long

    @Query("DELETE FROM sms_logs")
    suspend fun clearAll()
}
