package com.example.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import android.util.Log
import com.example.JaibCardsApplication
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * مستقبل البث الخاص بالرسائل القصيرة الواردة (SmsReceiver).
 * يعمل بأولوية عالية لالتقاط رسائل التحويل من "Jaib" فور وصولها ومعالجتها في الخلفية.
 */
class SmsReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return

        val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
        if (messages.isNullOrEmpty()) return

        // تجميع أجزاء الرسائل الطويلة (Multipart SMS) حسب اسم أو رقم المرسل
        val groupedBodies = linkedMapOf<String, StringBuilder>()
        for (sms in messages) {
            val sender = sms.displayOriginatingAddress ?: sms.originatingAddress ?: continue
            val body = sms.messageBody ?: ""
            groupedBodies.getOrPut(sender) { StringBuilder() }.append(body)
        }

        if (groupedBodies.isEmpty()) return

        val app = context.applicationContext as? JaibCardsApplication ?: return
        val pendingResult = goAsync()

        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            try {
                for ((sender, bodyBuilder) in groupedBodies) {
                    val fullBody = bodyBuilder.toString()
                    Log.d(TAG, "Received SMS from $sender")
                    app.repository.processMessage(sender = sender, body = fullBody)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error processing incoming SMS", e)
            } finally {
                pendingResult.finish()
            }
        }
    }

    companion object {
        private const val TAG = "JaibSmsReceiver"
    }
}
