package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * كيان يمثل الكروت المباعة التي تم صرفها وإرسالها للعملاء.
 */
@Entity(
    tableName = "sold_cards",
    indices = [
        Index(value = ["soldAt"]),
        Index(value = ["categoryAmount"])
    ]
)
data class SoldCard(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val categoryAmount: Int,
    val cardNumber: String,
    val customerPhone: String,
    val soldAt: Long = System.currentTimeMillis(),
    val rawMessageId: Long? = null
)
