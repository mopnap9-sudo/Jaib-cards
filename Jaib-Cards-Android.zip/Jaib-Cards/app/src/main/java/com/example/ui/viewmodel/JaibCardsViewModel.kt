package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.dao.CategoryStockCount
import com.example.data.local.dao.TodaySalesSummary
import com.example.data.local.entity.AppSettings
import com.example.data.local.entity.RechargeCard
import com.example.data.local.entity.SmsLog
import com.example.data.local.entity.SoldCard
import com.example.data.repository.BulkImportResult
import com.example.data.repository.CardRepository
import com.example.data.repository.SmsProcessingResult
import com.example.ui.localization.AppStrings
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class CategoryStockUiItem(
    val categoryAmount: Int,
    val count: Int,
    val isLowStock: Boolean
)

data class JaibCardsUiState(
    val settings: AppSettings = AppSettings(),
    val todaySales: TodaySalesSummary = TodaySalesSummary(),
    val categoryStocks: List<CategoryStockUiItem> = emptyList(),
    val totalAvailableStock: Int = 0,
    val availableCards: List<RechargeCard> = emptyList(),
    val soldCards: List<SoldCard> = emptyList(),
    val smsLogs: List<SmsLog> = emptyList()
)

class JaibCardsViewModel(
    private val repository: CardRepository
) : ViewModel() {

    private val _uiMessages = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val uiMessages: SharedFlow<String> = _uiMessages.asSharedFlow()

    private val baseDataFlow = combine(
        repository.settingsFlow,
        repository.observeTodaySalesSummary(),
        repository.categoryStockCountsFlow
    ) { settings, todaySales, stockCounts ->
        Triple(settings, todaySales, stockCounts)
    }

    private val listsFlow = combine(
        repository.allAvailableCardsFlow,
        repository.allSoldCardsFlow,
        repository.allSmsLogsFlow
    ) { availableCards, soldCards, smsLogs ->
        Triple(availableCards, soldCards, smsLogs)
    }

    val uiState: StateFlow<JaibCardsUiState> = combine(baseDataFlow, listsFlow) { base, lists ->
        val (settings, todaySales, stockCounts) = base
        val (availableCards, soldCards, smsLogs) = lists

        val countMap = stockCounts.associate { it.categoryAmount to it.count }
        val allCategories = (settings.parsedSupportedCategories() + countMap.keys).sorted()
        val categoryItems = allCategories.map { category ->
            val count = countMap[category] ?: 0
            CategoryStockUiItem(
                categoryAmount = category,
                count = count,
                isLowStock = count < LOW_STOCK_THRESHOLD
            )
        }

        JaibCardsUiState(
            settings = settings,
            todaySales = todaySales,
            categoryStocks = categoryItems,
            totalAvailableStock = availableCards.size,
            availableCards = availableCards,
            soldCards = soldCards,
            smsLogs = smsLogs
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = JaibCardsUiState()
    )

    fun toggleServiceActive(active: Boolean) {
        viewModelScope.launch {
            repository.setServiceActive(active)
        }
    }

    fun setLanguageCode(languageCode: String) {
        viewModelScope.launch {
            repository.setLanguageCode(languageCode)
        }
    }

    fun setDarkMode(isDarkMode: Boolean) {
        viewModelScope.launch {
            repository.setDarkMode(isDarkMode)
        }
    }

    fun saveSettings(updatedSettings: AppSettings, strings: AppStrings) {
        viewModelScope.launch {
            repository.updateSettings(updatedSettings)
            _uiMessages.tryEmit(strings.settingsSavedMessage)
        }
    }

    fun resetSettingsToDefaults(strings: AppStrings) {
        viewModelScope.launch {
            val current = repository.getSettingsOnce()
            repository.updateSettings(
                AppSettings(
                    id = 1,
                    isServiceActive = current.isServiceActive,
                    languageCode = current.languageCode,
                    isDarkMode = current.isDarkMode
                )
            )
            _uiMessages.tryEmit(strings.settingsSavedMessage)
        }
    }

    fun addCustomCategory(categoryAmount: Int) {
        if (categoryAmount <= 0) return
        viewModelScope.launch {
            val current = repository.getSettingsOnce()
            val updated = (current.parsedSupportedCategories() + categoryAmount)
                .sorted()
                .joinToString(",")
            repository.updateSettings(current.copy(supportedCategories = updated))
        }
    }

    fun importCardsBulk(
        categoryAmount: Int,
        rawText: String,
        skipDuplicates: Boolean,
        strings: AppStrings,
        onComplete: (BulkImportResult) -> Unit
    ) {
        viewModelScope.launch {
            val result = repository.importCardsBulk(categoryAmount, rawText, skipDuplicates)
            _uiMessages.tryEmit(strings.importResultMessage(result.addedCount, result.duplicateOrEmptyCount))
            onComplete(result)
        }
    }

    fun deleteAvailableCard(cardId: Long) {
        viewModelScope.launch {
            repository.deleteAvailableCard(cardId)
        }
    }

    fun clearSmsLogs() {
        viewModelScope.launch {
            repository.clearSmsLogs()
        }
    }

    fun clearSoldCards() {
        viewModelScope.launch {
            repository.clearSoldCards()
        }
    }

    fun simulateIncomingSms(sender: String, body: String, strings: AppStrings) {
        viewModelScope.launch {
            val feedback = when (val result = repository.processMessage(sender, body)) {
                is SmsProcessingResult.Dispensed ->
                    strings.simDispensedMessage(result.amount, result.cardNumber)
                is SmsProcessingResult.OutOfStock ->
                    strings.simOutOfStockMessage(result.amount)
                is SmsProcessingResult.MismatchAmount ->
                    strings.simMismatchMessage(result.amount)
                SmsProcessingResult.DuplicateIgnored -> strings.simDuplicateMessage
                SmsProcessingResult.ServiceInactive -> strings.simInactiveMessage
                SmsProcessingResult.ParseFailed -> strings.simParseFailedMessage
                SmsProcessingResult.FilteredOut -> strings.simFilteredOutMessage
            }
            _uiMessages.tryEmit(feedback)
        }
    }

    companion object {
        const val LOW_STOCK_THRESHOLD = 5

        fun provideFactory(repository: CardRepository): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    return JaibCardsViewModel(repository) as T
                }
            }
    }
}
