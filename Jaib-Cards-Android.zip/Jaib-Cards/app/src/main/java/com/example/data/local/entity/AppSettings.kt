package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * كيان إعدادات التطبيق المحفوظة محلياً في قاعدة بيانات Room.
 */
@Entity(tableName = "app_settings")
data class AppSettings(
    @PrimaryKey val id: Int = 1,
    val isServiceActive: Boolean = true,
    val languageCode: String = DEFAULT_LANGUAGE,
    val isDarkMode: Boolean = true,
    val ownerPhone: String = "",
    val allowedSender: String = DEFAULT_ALLOWED_SENDER,
    val requiredKeyword: String = DEFAULT_KEYWORD,
    val supportedCategories: String = DEFAULT_SUPPORTED_CATEGORIES,
    val successTemplate: String = DEFAULT_SUCCESS_TEMPLATE,
    val outOfStockTemplate: String = DEFAULT_OUT_OF_STOCK_TEMPLATE,
    val mismatchTemplate: String = DEFAULT_MISMATCH_TEMPLATE
) {
    companion object {
        const val DEFAULT_LANGUAGE = "ar"
        const val DEFAULT_ALLOWED_SENDER = "Jaib"
        const val DEFAULT_KEYWORD = "اضيف"
        const val DEFAULT_SUPPORTED_CATEGORIES = "500,1000,2000,5000,10000"
        const val DEFAULT_SUCCESS_TEMPLATE =
            "شكراً لاستخدامك خدمتنا. كرت فئة {الفئة} ر.ي الخاص بك هو: {رقم_الكرت}"
        const val DEFAULT_OUT_OF_STOCK_TEMPLATE =
            "عذراً، كروت فئة {الفئة} ر.ي غير متوفرة حالياً. تم إبلاغ الإدارة وسيتم تزويدك بها قريباً."
        const val DEFAULT_MISMATCH_TEMPLATE =
            "عذراً، المبلغ المحول ({المبلغ} ر.ي) لا يطابق فئات الكروت المتوفرة. يرجى التواصل مع الإدارة."
    }

    fun parsedSupportedCategories(): Set<Int> {
        return supportedCategories.split(",", "،", " ")
            .mapNotNull { it.trim().toIntOrNull() }
            .filter { it > 0 }
            .toSet()
    }
}
