package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// لوحة الألوان الرسمية للتطبيق: الأسود الداكن، الأبيض النقي، والأحمر القاني
val CrimsonRed = Color(0xFFE11D38)
val CrimsonRedDark = Color(0xFFC0102A)
val CrimsonRedSoft = Color(0xFFFF3B5C)
val VelvetRedDark = Color(0xFF3A0B14)
val VelvetRedLight = Color(0xFFFFE5E9)
val DeepRedText = Color(0xFF680012)
val SoftRedTint = Color(0xFFFFD9DE)

// درجات الأسود الداكن (Dark Palette)
val ObsidianBlack = Color(0xFF0A0A0C)
val CharcoalSurface = Color(0xFF131317)
val GraphiteElevated = Color(0xFF1C1C22)
val GraphiteHigh = Color(0xFF25252D)
val DarkOutline = Color(0xFF30303B)
val DarkMutedText = Color(0xFFA6A6B4)

// درجات الأبيض النقي (Light Palette)
val AlabasterWhite = Color(0xFFFAFAFC)
val PureWhite = Color(0xFFFFFFFF)
val PorcelainSurface = Color(0xFFF2F2F6)
val PorcelainHigh = Color(0xFFE7E7EE)
val LightOutline = Color(0xFFD9D9E2)
val InkBlack = Color(0xFF111115)
val LightMutedText = Color(0xFF5A5A66)
