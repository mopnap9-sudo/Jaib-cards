package com.example.data.sms

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.telephony.SmsManager
import android.util.Log
import androidx.core.content.ContextCompat

/**
 * واجهة موحدة لإرسال الرسائل القصيرة (تسهل الاختبار والفصل بين الطبقات).
 */
interface SmsDispatcher {
    fun sendSms(destinationPhone: String, message: String): Boolean
}

/**
 * التنفيذ الفعلي لإرسال الرسائل القصيرة باستخدام SmsManager الخاص بنظام أندرويد.
 */
class AndroidSmsDispatcher(private val context: Context) : SmsDispatcher {

    override fun sendSms(destinationPhone: String, message: String): Boolean {
        val cleanPhone = destinationPhone.trim()
        if (cleanPhone.isBlank() || message.isBlank()) {
            Log.w(TAG, "Cannot send SMS: phone or message is blank")
            return false
        }

        val hasSendPermission = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.SEND_SMS
        ) == PackageManager.PERMISSION_GRANTED

        if (!hasSendPermission) {
            Log.w(TAG, "SEND_SMS permission is not granted; SMS to $cleanPhone skipped")
            return false
        }

        return try {
            val smsManager: SmsManager = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                context.getSystemService(SmsManager::class.java)
            } else {
                @Suppress("DEPRECATION")
                SmsManager.getDefault()
            }

            val parts = smsManager.divideMessage(message)
            if (parts.size > 1) {
                smsManager.sendMultipartTextMessage(cleanPhone, null, parts, null, null)
            } else {
                smsManager.sendTextMessage(cleanPhone, null, message, null, null)
            }
            Log.i(TAG, "SMS dispatched to $cleanPhone (${parts.size} part(s))")
            true
        } catch (e: SecurityException) {
            Log.e(TAG, "SecurityException sending SMS to $cleanPhone", e)
            false
        } catch (e: Exception) {
            Log.e(TAG, "Failed to send SMS to $cleanPhone", e)
            false
        }
    }

    companion object {
        private const val TAG = "AndroidSmsDispatcher"
    }
}
