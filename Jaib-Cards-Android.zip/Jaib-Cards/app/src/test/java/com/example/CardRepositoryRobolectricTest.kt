package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.local.entity.AppSettings
import com.example.data.local.entity.SmsStatus
import com.example.data.repository.CardRepository
import com.example.data.repository.SmsProcessingResult
import com.example.data.sms.SmsDispatcher
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class CardRepositoryRobolectricTest {

    private lateinit var database: AppDatabase
    private lateinit var fakeSmsDispatcher: FakeSmsDispatcher
    private lateinit var repository: CardRepository

    class FakeSmsDispatcher : SmsDispatcher {
        val sentMessages = mutableListOf<Pair<String, String>>()
        override fun sendSms(destinationPhone: String, message: String): Boolean {
            sentMessages.add(destinationPhone to message)
            return true
        }
    }

    @Before
    fun setup() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        database = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        fakeSmsDispatcher = FakeSmsDispatcher()
        repository = CardRepository(database, fakeSmsDispatcher)
    }

    @After
    fun teardown() {
        database.close()
    }

    @Test
    fun `parseMessage handles Arabic numerals and riyal formats`() {
        val body = "تم إيداع مبلغ ١٬٠٠٠ ر.ي في حسابك، اضيف من الرقم +967771234567"
        val parsed = repository.parseMessage(body)
        assertEquals(1000, parsed.amount)
        assertEquals("771234567", parsed.phoneNumber)
    }

    @Test
    fun `parseMessage picks last phone number and handles English digits`() {
        val body = "اضيف 500.00 ريال من 770000111 إلى حسابك رقم 733445566"
        val parsed = repository.parseMessage(body)
        assertEquals(500, parsed.amount)
        assertEquals("733445566", parsed.phoneNumber)
    }

    @Test
    fun `processMessage dispenses first available card and moves to sold table`() = runTest {
        repository.updateSettings(AppSettings(ownerPhone = "777000999"))
        repository.importCardsBulk(500, "PIN-1111\nPIN-2222", skipDuplicates = true)

        val result = repository.processMessage(
            sender = "jaib",
            body = "اضيف لحسابك مبلغ 500 ر.ي من الرقم 771234567",
            nowMillis = 1_000_000L
        )

        assertTrue(result is SmsProcessingResult.Dispensed)
        val dispensed = result as SmsProcessingResult.Dispensed
        assertEquals("PIN-1111", dispensed.cardNumber)
        assertEquals("771234567", dispensed.customerPhone)

        val remaining = repository.allAvailableCardsFlow.first()
        val sold = repository.allSoldCardsFlow.first()
        val logs = repository.allSmsLogsFlow.first()

        assertEquals(1, remaining.size)
        assertEquals("PIN-2222", remaining.first().cardNumber)
        assertEquals(1, sold.size)
        assertEquals("PIN-1111", sold.first().cardNumber)
        assertEquals(SmsStatus.DISPENSED, logs.first().status)
        assertEquals(1, fakeSmsDispatcher.sentMessages.size)
        assertTrue(fakeSmsDispatcher.sentMessages.first().second.contains("PIN-1111"))
    }

    @Test
    fun `processMessage ignores duplicate message within 60 seconds`() = runTest {
        repository.importCardsBulk(1000, "CARD-A\nCARD-B", skipDuplicates = true)
        val body = "اضيف مبلغ 1000 ر.ي من 777112233"

        val first = repository.processMessage("Jaib", body, nowMillis = 100_000L)
        val second = repository.processMessage("Jaib", body, nowMillis = 130_000L)

        assertTrue(first is SmsProcessingResult.Dispensed)
        assertTrue(second is SmsProcessingResult.DuplicateIgnored)
        assertEquals(1, repository.allAvailableCardsFlow.first().size)
        assertEquals(1, repository.allSoldCardsFlow.first().size)
    }

    @Test
    fun `processMessage handles out of stock and alerts owner`() = runTest {
        repository.updateSettings(AppSettings(ownerPhone = "777888999"))

        val result = repository.processMessage(
            sender = "Jaib",
            body = "اضيف مبلغ 2000 ر.ي من العميل 771112233",
            nowMillis = 200_000L
        )

        assertTrue(result is SmsProcessingResult.OutOfStock)
        assertEquals(2, fakeSmsDispatcher.sentMessages.size)
        assertEquals("771112233", fakeSmsDispatcher.sentMessages[0].first)
        assertEquals("777888999", fakeSmsDispatcher.sentMessages[1].first)
        assertEquals(SmsStatus.OUT_OF_STOCK, repository.allSmsLogsFlow.first().first().status)
    }

    @Test
    fun `processMessage handles mismatch amount`() = runTest {
        val result = repository.processMessage(
            sender = "Jaib",
            body = "اضيف مبلغ 750 ر.ي من 775556667",
            nowMillis = 300_000L
        )

        assertTrue(result is SmsProcessingResult.MismatchAmount)
        assertEquals(1, fakeSmsDispatcher.sentMessages.size)
        assertEquals(SmsStatus.MISMATCH_AMOUNT, repository.allSmsLogsFlow.first().first().status)
    }
}
