package com.example

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class MainActivityLaunchRobolectricTest {

    @get:Rule
    val composeRule = createAndroidComposeRule<MainActivity>()

    @Test
    fun mainActivity_launchesAndNavigatesAllTabs() {
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("service_active_switch").assertIsDisplayed()

        composeRule.onNodeWithTag("nav_tab_inventory").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("bulk_import_input").assertIsDisplayed()

        composeRule.onNodeWithTag("nav_tab_logs").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("tab_raw_sms_logs").assertIsDisplayed()

        composeRule.onNodeWithTag("nav_tab_settings").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("lang_english_button").assertIsDisplayed()
    }
}
